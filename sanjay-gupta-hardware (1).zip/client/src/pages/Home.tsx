import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Phone, MapPin, Mail, Wrench, Hammer, Zap } from "lucide-react";

/**
 * Sanjay Gupta Hardware - Professional Hardware Shop Website
 * Design: Professional Tradecraft - trustworthy, expert, approachable
 * Color: Deep Steel Blue (#1F4788) primary, Warm Orange (#E67E22) accent
 * Typography: Poppins for headings, Inter for body
 */

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Navigation Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-border shadow-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img 
              src="/manus-storage/logo-icon_fc3f920a.png" 
              alt="Sanjay Gupta Hardware Logo" 
              className="w-10 h-10"
            />
            <div>
              <h1 className="text-xl font-bold text-primary">Sanjay Gupta</h1>
              <p className="text-xs text-muted-foreground">Hardware Shop</p>
            </div>
          </div>
          <nav className="hidden md:flex gap-8 items-center">
            <a href="#products" className="text-foreground hover:text-primary transition-colors">Products</a>
            <a href="#about" className="text-foreground hover:text-primary transition-colors">About</a>
            <a href="#contact" className="text-foreground hover:text-primary transition-colors">Contact</a>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/5 to-secondary/5 py-12 md:py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
            {/* Hero Text */}
            <div className="flex flex-col gap-6">
              <div>
                <p className="text-secondary font-semibold text-sm mb-2 heading-accent">Welcome to</p>
                <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">
                  Sanjay Gupta Hardware
                </h1>
                <p className="text-lg text-foreground/80 mb-2">
                  Your trusted local hardware partner for all building and repair needs
                </p>
                <p className="text-base text-muted-foreground">
                  Quality tools, expert advice, and competitive prices. Serving our community with excellence for years.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  className="bg-secondary hover:bg-secondary/90 text-secondary-foreground font-semibold py-6 px-8 rounded-lg transition-all hover:shadow-lg"
                >
                  Browse Products
                </Button>
                <Button 
                  variant="outline" 
                  className="border-primary text-primary hover:bg-primary/5 font-semibold py-6 px-8 rounded-lg"
                >
                  Get in Touch
                </Button>
              </div>
            </div>

            {/* Hero Image */}
            <div className="relative h-96 md:h-full min-h-96 rounded-lg overflow-hidden shadow-xl">
              <img 
                src="/manus-storage/hero-banner_d2a1f44c.png" 
                alt="Hardware Store Interior" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
            </div>
          </div>
        </div>
      </section>

      {/* About Owner Section */}
      <section id="about" className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            {/* Owner Image */}
            <div className="relative">
              <div className="relative h-96 md:h-full min-h-96 rounded-lg overflow-hidden shadow-xl border-4 border-primary/10">
                <img 
                  src="/manus-storage/owner-sanjay_99f38665.jpg" 
                  alt="Sanjay Gupta - Owner" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-4 -right-4 bg-secondary text-secondary-foreground px-6 py-3 rounded-lg shadow-lg font-semibold">
                Trusted Since Day 1
              </div>
            </div>

            {/* About Text */}
            <div className="flex flex-col gap-6">
              <div>
                <p className="text-secondary font-semibold text-sm mb-2 heading-accent">About the Owner</p>
                <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
                  Sanjay Gupta
                </h2>
                <p className="text-base text-foreground/80 leading-relaxed mb-4">
                  With years of experience in the hardware business, Sanjay Gupta has built a reputation for providing quality products and expert advice to customers throughout the community. His commitment to customer satisfaction and product excellence has made Sanjay Gupta Hardware the go-to destination for all hardware needs.
                </p>
                <p className="text-base text-foreground/80 leading-relaxed">
                  Whether you're a professional contractor or a DIY enthusiast, Sanjay brings personal attention and expertise to every customer interaction. His deep knowledge of tools, materials, and building techniques ensures you get exactly what you need.
                </p>
              </div>

              {/* Key Values */}
              <div className="grid grid-cols-1 gap-4 mt-4">
                <div className="flex gap-4 items-start">
                  <div className="bg-secondary/10 p-3 rounded-lg">
                    <Wrench className="w-6 h-6 text-secondary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">Quality Products</h4>
                    <p className="text-sm text-muted-foreground">Only the best tools and materials</p>
                  </div>
                </div>
                <div className="flex gap-4 items-start">
                  <div className="bg-secondary/10 p-3 rounded-lg">
                    <Hammer className="w-6 h-6 text-secondary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">Expert Advice</h4>
                    <p className="text-sm text-muted-foreground">Professional guidance for your projects</p>
                  </div>
                </div>
                <div className="flex gap-4 items-start">
                  <div className="bg-secondary/10 p-3 rounded-lg">
                    <Zap className="w-6 h-6 text-secondary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">Competitive Prices</h4>
                    <p className="text-sm text-muted-foreground">Best value for your money</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="py-16 md:py-24 bg-gradient-to-br from-primary/5 to-secondary/5">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <p className="text-secondary font-semibold text-sm mb-2 heading-accent">Our Offerings</p>
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
              Complete Hardware Solutions
            </h2>
            <p className="text-base text-muted-foreground max-w-2xl mx-auto">
              From hand tools to electrical supplies, we stock everything you need for your projects
            </p>
          </div>

          {/* Product Categories Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            {[
              {
                title: "Hand Tools",
                description: "Hammers, wrenches, screwdrivers, pliers, and more",
                icon: "🔨"
              },
              {
                title: "Power Tools",
                description: "Drills, saws, grinders, and professional equipment",
                icon: "⚡"
              },
              {
                title: "Plumbing Supplies",
                description: "Pipes, fittings, valves, and plumbing fixtures",
                icon: "🔧"
              },
              {
                title: "Electrical",
                description: "Wiring, switches, outlets, and electrical components",
                icon: "💡"
              },
              {
                title: "Building Materials",
                description: "Lumber, fasteners, adhesives, and construction supplies",
                icon: "🏗️"
              },
              {
                title: "Paint & Finishing",
                description: "Paints, brushes, rollers, and finishing supplies",
                icon: "🎨"
              }
            ].map((category, idx) => (
              <Card 
                key={idx}
                className="p-6 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border border-border/50 bg-white"
              >
                <div className="text-4xl mb-4">{category.icon}</div>
                <h3 className="text-xl font-bold text-primary mb-2">{category.title}</h3>
                <p className="text-sm text-muted-foreground">{category.description}</p>
              </Card>
            ))}
          </div>

          {/* Featured Products Image */}
          <div className="relative h-96 rounded-lg overflow-hidden shadow-xl mb-8">
            <img 
              src="/manus-storage/hardware-products_ac3b3027.png" 
              alt="Featured Products" 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div>
              <p className="text-secondary font-semibold text-sm mb-2 heading-accent">Get in Touch</p>
              <h2 className="text-3xl md:text-4xl font-bold text-primary mb-8">
                Visit Us or Contact Us
              </h2>

              <div className="space-y-6">
                <div className="flex gap-4 items-start">
                  <div className="bg-secondary/10 p-4 rounded-lg flex-shrink-0">
                    <MapPin className="w-6 h-6 text-secondary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-1">Location</h4>
                    <p className="text-muted-foreground">
                      Sanjay Gupta Hardware<br />
                      Your City, State<br />
                      India
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 items-start">
                  <div className="bg-secondary/10 p-4 rounded-lg flex-shrink-0">
                    <Phone className="w-6 h-6 text-secondary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-1">Phone</h4>
                    <p className="text-muted-foreground">
                      <a href="tel:+919876543210" className="hover:text-primary transition-colors">
                        +91 98765 43210
                      </a>
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 items-start">
                  <div className="bg-secondary/10 p-4 rounded-lg flex-shrink-0">
                    <Mail className="w-6 h-6 text-secondary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-1">Email</h4>
                    <p className="text-muted-foreground">
                      <a href="mailto:info@sanjaygupta.com" className="hover:text-primary transition-colors">
                        info@sanjaygupta.com
                      </a>
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-8 p-6 bg-primary/5 rounded-lg border border-primary/10">
                <h4 className="font-semibold text-foreground mb-2">Business Hours</h4>
                <p className="text-sm text-muted-foreground">
                  Monday - Saturday: 9:00 AM - 8:00 PM<br />
                  Sunday: 10:00 AM - 6:00 PM<br />
                  <span className="text-secondary font-semibold">Closed on National Holidays</span>
                </p>
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-gradient-to-br from-primary/5 to-secondary/5 p-8 rounded-lg border border-primary/10">
              <h3 className="text-2xl font-bold text-primary mb-6">Send us a Message</h3>
              <form className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">Name</label>
                  <input 
                    type="text" 
                    placeholder="Your name" 
                    className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 bg-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">Email</label>
                  <input 
                    type="email" 
                    placeholder="your@email.com" 
                    className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 bg-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">Phone</label>
                  <input 
                    type="tel" 
                    placeholder="+91 98765 43210" 
                    className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 bg-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">Message</label>
                  <textarea 
                    placeholder="Tell us about your inquiry..." 
                    rows={4}
                    className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 bg-white resize-none"
                  ></textarea>
                </div>
                <Button 
                  className="w-full bg-secondary hover:bg-secondary/90 text-secondary-foreground font-semibold py-3 rounded-lg transition-all"
                >
                  Send Message
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary text-primary-foreground py-8 md:py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <h4 className="font-bold text-lg mb-2">Sanjay Gupta Hardware</h4>
              <p className="text-sm opacity-90">
                Your trusted local hardware partner for all building and repair needs.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#products" className="hover:opacity-80 transition-opacity">Products</a></li>
                <li><a href="#about" className="hover:opacity-80 transition-opacity">About</a></li>
                <li><a href="#contact" className="hover:opacity-80 transition-opacity">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <p className="text-sm opacity-90">
                Phone: +91 98765 43210<br />
                Email: info@sanjaygupta.com
              </p>
            </div>
          </div>
          <div className="border-t border-primary-foreground/20 pt-8 text-center text-sm opacity-80">
            <p>&copy; 2026 Sanjay Gupta Hardware. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
