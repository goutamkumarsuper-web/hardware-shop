# Sanjay Gupta Hardware - Design Strategy

## Design Philosophy: Professional Tradecraft

**Chosen Approach:** A trusted, professional hardware shop website that conveys reliability, expertise, and quality. The design emphasizes trustworthiness through clean layouts, professional imagery, and a focus on the owner's personal connection to the business.

### Design Movement
Industrial Modern meets Small Business Authenticity—combining professional aesthetics with the personal touch of a family-run hardware shop.

### Core Principles
1. **Trust Through Clarity**: Clean, organized layouts that make it easy to find products and information
2. **Personal Connection**: Feature the owner prominently to build customer relationships
3. **Professional Competence**: Showcase expertise through organized product categories and detailed information
4. **Accessibility**: Easy navigation for customers of all ages and technical abilities

### Color Philosophy
- **Primary**: Deep Steel Blue (#1F4788) - conveys professionalism, reliability, and trustworthiness
- **Secondary**: Warm Orange (#E67E22) - adds approachability and energy (accent for CTAs)
- **Neutral**: Clean whites and light grays - for clarity and readability
- **Accent**: Muted green (#27AE60) - represents hardware/tools and growth
- **Reasoning**: The combination creates a professional yet approachable brand that feels both established and customer-friendly

### Layout Paradigm
- **Hero Section**: Feature the owner's image prominently with shop name and tagline
- **Product Categories**: Grid-based showcase of main product lines
- **About Section**: Personal story connecting owner to the business
- **Services/Products**: Organized, scannable sections with clear CTAs
- **Contact**: Easy-to-find contact information and location

### Signature Elements
1. **Owner's Portrait**: Central visual element building personal connection
2. **Tool Icons**: Subtle hardware/tool graphics throughout
3. **Professional Cards**: Product/service cards with consistent styling

### Interaction Philosophy
- Smooth hover effects on interactive elements
- Clear visual feedback for buttons and links
- Responsive design for mobile customers
- Fast, snappy interactions that feel professional

### Animation
- Subtle fade-ins on page load
- Smooth hover transitions (150-200ms) on cards and buttons
- Scale effects on interactive elements (0.97 on active)
- Staggered entrance animations for product grids

### Typography System
- **Display Font**: Poppins Bold (700) - for headings, conveying confidence
- **Body Font**: Inter Regular (400) - for readability and professionalism
- **Accent Font**: Poppins SemiBold (600) - for subheadings and emphasis

### Brand Essence
**One-liner**: Your trusted local hardware partner for all building and repair needs.
**Personality**: Reliable, Professional, Approachable, Knowledgeable

### Brand Voice
- Headlines: Direct, confident, and benefit-focused
- CTAs: Action-oriented and clear
- Microcopy: Helpful and professional
- **Example Headlines**: 
  - "Quality Hardware You Can Trust"
  - "Expert Advice, Competitive Prices"

### Logo & Visual Identity
- Wordmark: "Sanjay Gupta Hardware" in Poppins Bold with a subtle tool icon
- Color: Deep Steel Blue primary with Orange accent
- Style: Professional, modern, trustworthy

### Signature Brand Color
**Deep Steel Blue (#1F4788)** - Unmistakably professional and trustworthy, representing expertise and reliability in the hardware business.

## Style Decisions
- Use professional photography and the owner's image as primary visual assets
- Maintain consistent spacing and alignment throughout
- Use subtle shadows for depth without being distracting
- Ensure all text meets WCAG contrast standards
- Mobile-first responsive design
